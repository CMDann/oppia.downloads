# Copyright 2012 Google Inc. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS-IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Controllers for Oppia resources (templates, images)."""

__author__ = 'sll@google.com (Sean Lip)'

import json

from controllers.base import BaseHandler
import feconf
from models.image import Image
import utils


class LibHandler(BaseHandler):
    """Assembles and returns library code."""

    def get_footer_js_code(self):
        return '\n'.join(
            [utils.get_file_contents(filepath)
             for filepath in feconf.FOOTER_JS_FILES])

    def get(self, lib_type):
        """Handles GET requests for CSS and JS library code."""

        if lib_type == 'footer_js':
            self.response.headers['Content-Type'] = 'application/javascript'
            self.response.write(self.get_footer_js_code())
        else:
            self.error(404)


class TemplateHandler(BaseHandler):
    """Retrieves an editor template."""

    def get(self, template_type):
        """Handles GET requests."""
        self.response.write(feconf.JINJA_ENV.get_template(
            'editor/views/%s_editor.html' % template_type).render({}))


class ImageHandler(BaseHandler):
    """Handles image uploads and retrievals."""

    def get(self, image_id):
        """Returns an image.

        Args:
            image_id: string representing the image id.
        """
        image = Image.get_by_id(image_id)
        if image:
            # TODO(sll): Support other image types.
            self.response.headers['Content-Type'] = str('image/%s' % image.format)
            self.response.write(image.raw)
        else:
            self.response.write('No image')

    def post(self):
        """Saves an image uploaded by a content creator."""
        raw = self.request.get('image')
        if raw:
            image_id = Image.create(raw)
            self.response.write(json.dumps({'image_id': image_id}))
        else:
            raise self.InvalidInputException('No image supplied')
